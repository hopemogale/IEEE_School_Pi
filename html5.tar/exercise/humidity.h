void read_temp_hum(double *temp, double *hum);
